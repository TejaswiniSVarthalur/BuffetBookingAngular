import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from '../app.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { routes } from '../app-routing.module';

describe('Test AppComponent', () => {
  let component: AppComponent;
    let fixture: ComponentFixture<AppComponent>;
    let link: DebugElement;
    let routerOutletTag: DebugElement;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    link=fixture.debugElement.query(By.css('.nav > li > a'));
    routerOutletTag=fixture.debugElement.query(By.css('router-outlet'));

  });

  it('TAC 1/2 - AppComp should be created', () => {   // 1. AppComp Creation
    expect(component).toBeTruthy();
  });


  it('TAC 2/2 - to check the routerOutletTag',()=>{ // 2. Router tag
    expect(routerOutletTag).toBeTruthy();
  })


});
