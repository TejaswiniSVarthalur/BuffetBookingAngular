import { TestBed, inject, async } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { XHRBackend, Response, ResponseOptions } from '@angular/http';

import { BuffetBookingService } from '../buffet-booking/buffet-booking.service';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
// import 'rxjs/add/observable/of';

///////////////////////Service initialization///////////////
describe('Test service - BuffetBookingService', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BuffetBookingService, { provide: XHRBackend, useClass: MockBackend }]
    })
      .compileComponents();
  }));

  it('TS 1/7  Can Intantiate service when injected', inject([BuffetBookingService], (service: BuffetBookingService) => {
    expect(service instanceof BuffetBookingService).toBe(true);
  }));

  it('TS 2/7 Can intantiate service with new keyword', inject([HttpClient], (http: HttpClient) => {
    expect(http).not.toBeNull('HttpClient should be provided');
    const service = new BuffetBookingService(http);
    expect(service instanceof BuffetBookingService).toBe(true, 'New service should be ok');
  }));

  it('TS 3/7 Can provide mockBackend as XHRBackend', inject([XHRBackend], (backend: MockBackend) => {
    expect(backend).not.toBeNull('backend should be provided');
  }))
})

///////////////////////Fetching valid data///////////////
describe('Fetching data through service', () => {

  let httpMock: HttpTestingController;
  let dataService: BuffetBookingService;
  const mockResponse = '{"buffetName":"ChineseSpcl","bookedOn":2018-6-14,"emailId":"luvina@infy.com","plateCount":4}';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BuffetBookingService]
    });
    httpMock = TestBed.get(HttpTestingController);
    dataService = TestBed.get(BuffetBookingService);
  });

  it('TS 4/7 Service should be created', inject([BuffetBookingService], (service: BuffetBookingService) => {
    expect(service).toBeTruthy();
  }));

  it('TS 5/7 Service should return observable', inject([HttpTestingController, BuffetBookingService], (httpMock, service) => {
    service.bookBuffet().subscribe((response) => {
      expect(response).toBe('{"buffetName":"ChineseSpcl","bookedOn":2018-6-14,"emailId":"luvina@infy.com","plateCount":4}')
    })
    const mockReq = httpMock.expectOne(dataService.url);
    mockReq.flush(mockResponse);
    httpMock.verify();
  }))

  it('TS 6/7 Service Should call appropriate URL',() => {
    expect(dataService.url).toBe('http://localhost:3000/bookBuffet');
  })

  it('TS 7/7 Service should be called using POST method',inject([HttpClient], (http: HttpClient)=>{
    const spy = spyOn(http,"post").and.returnValue(of({message:'Success'}));
    dataService.bookBuffet(mockResponse);
    expect(spy).toHaveBeenCalled();
  }))
});



