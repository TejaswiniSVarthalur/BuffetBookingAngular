import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ReactiveFormsModule, FormGroup, FormControl, AbstractControl } from '@angular/forms';
import { DebugElement } from "@angular/core";
import { RouterTestingModule } from '@angular/router/testing';
import { Observable, of, throwError } from 'rxjs';
// import 'rxjs/add/observable/of';

import { BuffetBookingComponent } from '../buffet-booking/buffet-booking.component';
import { BuffetBookingService } from '../buffet-booking/buffet-booking.service';
import { MessagePipe } from '../buffet-booking/message.pipe';
import { isObject } from 'util';
import { truncate } from 'fs';


class BuffetBookingServiceStub {
  bookBuffet() { }
}
describe('Testing BuffetBookingComponent', () => {
  let component: BuffetBookingComponent;
  let fixture: ComponentFixture<BuffetBookingComponent>;
  let buffetBookingService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule],
      declarations: [BuffetBookingComponent, MessagePipe],
      providers: [{ provide: BuffetBookingService, useClass: BuffetBookingServiceStub }] //To stub the service so we can use spyOn later on
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuffetBookingComponent);
    component = fixture.componentInstance;
    buffetBookingService = TestBed.get(BuffetBookingService);
    fixture.detectChanges();
    jasmine.MAX_PRETTY_PRINT_DEPTH = 2;
  });

  it('TSC 1/60 - Component should be created', () => {
    expect(component).toBeTruthy();
  });

  describe('Verifying the fields in buffetBookingForm', () => {

    // //////////////////////// 1st Field /////////////////////////////  

    //buffetName field when no value is given
    describe('Buffet Name field which is empty', () => {
      let errors;
      let buffetName;
      let buffetNameSpan;

      beforeEach(() => {
        buffetName = component.buffetBookingForm.controls['buffetName'];
        buffetName.setValue('');
        fixture.detectChanges();
        errors = buffetName.errors;
        buffetNameSpan = fixture.debugElement.query(By.css('#buffetNameError'));
      })


      it('TSC 2/60 - Buffet Name should be invalid', () => {
        expect(buffetName.valid).toBeFalsy();
      });

      it('TSC 3/60 - Buffet Name should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

      //let emailIdSpanPresent = fixture.debugElement.query(By.css('#buffetNameError'));

      it('TSC 4/60 - Buffet Name should not display the error message initialy', () => {
        expect(buffetNameSpan).toBeFalsy();
      });
    })

    //buffetName field when a value is given
    describe('Buffet Name field when correct value is given', () => {
      let errors;
      let buffetName: AbstractControl;
      let buffetNameSpan;

      beforeEach(() => {
        buffetName = component.buffetBookingForm.controls['buffetName'];
        buffetName.setValue('SouthIndianFestivalSpecial');
        buffetName.markAsDirty();
        fixture.detectChanges();
        buffetNameSpan = fixture.debugElement.query(By.css('#buffetNameError'));
        errors = buffetName.errors;
      });


      it('TSC 5/60 - Buffet Name should be valid', () => {
        expect(buffetName.valid).toBeTruthy();
      });


      it('TSC 6/60 - Buffet Name should not contain error', () => {
        expect(errors).toBeFalsy();

      });


      it('TSC 7/60 - Buffet Name should not display the error message', () => {
        expect(buffetNameSpan).toBeFalsy();
      })
    });

    //Checking options used in select
    describe('Validate if the options used are as provided', () => {
      it('TSC 8/60 - Checks for the options in Select tag', () => {
        let buffetNameDisabledOptionTag = fixture.debugElement.query(By.css('#buffetName'));
        let optionArray: DebugElement[] = buffetNameDisabledOptionTag.children;
        let flag: number = 0;

        for (let element of optionArray) {
          if (element.nativeElement.value == '') {
            if (element.nativeElement.disabled) {
              flag++;
            }
          }
          else if (element.nativeElement.innerHTML == 'South Indian Festival Special') {
            if (element.nativeElement.value == 'SouthIndianFestivalSpecial') {
              flag++;
            }
          }
          else if (element.nativeElement.innerHTML == 'North Indian Festival Special') {
            if (element.nativeElement.value == 'NorthIndianFestivalSpecial') {
              flag++;
            }
          }
          else if (element.nativeElement.innerHTML == 'Chineese Special') {
            if (element.nativeElement.value == 'ChineeseSpecial') {
              flag++;
            }
          }
        }
        expect(flag).toBe(4);
      })
    })


    //////////////////////// 2nd Field /////////////////////////////   

    //Email id when no value is given
    describe('Email id when value is not given', () => {
      let errors;
      let emailId;
      let emailIdSpan;

      beforeEach(() => {
        emailId = component.buffetBookingForm.controls['emailId'];
        emailId.setValue('');
        fixture.detectChanges();
        errors = emailId.errors;
      });

      it('TSC 9/60 - Email id should be invalid', () => {
        expect(emailId.valid).toBeFalsy();
      });

      it('TSC 10/60 - Email Id should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

      it('TSC 11/60 - Email id should not display error message initally', () => {
        //let emailIdSpanPresent = fixture.debugElement.query(By.css('#emailIdError'));
        emailIdSpan = fixture.debugElement.query(By.css('#emailIdError'));
        alert('Data in try ' + emailIdSpan);
        expect(emailIdSpan).toBeFalsy();
      })
    })

    //Email id field when a correct value is given
    describe('Email id field when correct value is given', () => {
      let errors;
      let emailId: AbstractControl;
      let emailIdSpan;

      beforeEach(() => {
        emailId = component.buffetBookingForm.controls['emailId'];
        emailId.setValue('andy@gmail.com');
        emailId.markAsDirty();
        fixture.detectChanges();
        errors = emailId.errors;
      });

      it('TSC 12/60 - Email id should be valid', () => {
        expect(emailId.valid).toBeTruthy();

      });

      it('TSC 13/60 - Email id should not contain error', () => {
        expect(errors).toBeFalsy();

      });

      it('TSC 14/60 - Email id should not display the error message', () => {
        emailIdSpan = fixture.debugElement.query(By.css('#emailIdError'));
        alert("Value for correct input: " + emailIdSpan)
        expect(emailIdSpan).toBeFalsy();
      })

      it('TSC 15/60 - Email id should be of type email', () => {
        let emailType = fixture.debugElement.query(By.css('#emailId'));
        expect(emailType.attributes['type']).toBe('email');
      })
    });

    //Email id field when an incorrect value is given
    describe('Email id field when incorrect value is given', () => {
      let errors;
      let emailId: AbstractControl;
      let emailIdSpan;

      beforeEach(() => {
        emailId = component.buffetBookingForm.controls['emailId'];
        emailId.setValue('andy.com');
        emailId.markAsDirty();
        fixture.detectChanges();
        errors = emailId.errors;
      });

      it('TSC 16/60 - Email id should be invalid', () => {
        expect(emailId.valid).toBeFalsy();

      });

      it('TSC 17/60 - Email id should contain error', () => {
        expect(errors).toBeTruthy();

      });

      it('TSC 18/60 - Email id should display the error message', () => {
        emailIdSpan = fixture.debugElement.query(By.css('#emailIdError'));
        alert("Value for incorrect input: " + emailIdSpan)
        expect(emailIdSpan).toBeTruthy();
      })

      it('TSC 19/60 - Email id should be of type email', () => {
        expect(errors['email']).toBeTruthy();
      })
    });


    //////////////////////// 3rd Field /////////////////////////////

    //plateCount field with no input
    describe('plateCount field with no input', () => {
      let errors;
      let plateCount: AbstractControl;
      let plateCountSpan;

      beforeEach(() => {
        plateCount = component.buffetBookingForm.controls['plateCount'];
        plateCount.setValue('');
        fixture.detectChanges();
        errors = plateCount.errors;
        plateCountSpan = fixture.debugElement.query(By.css('#plateCountError'));
      });

      it('TSC 20/60 - Plate count should be invalid', () => {
        expect(plateCount.valid).toBeFalsy();
      });


      it('TSC 21/60 - Plate count should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

      it('TSC 22/60 - Plate count should not display the error message initialy', () => {
        expect(plateCountSpan).toBeFalsy();
      });
    })

    //Plate count with correct value
    describe('Plate count field when correct value is given', () => {
      let errors;
      let plateCount: AbstractControl;
      let plateCountSpan;

      beforeEach(() => {
        plateCount = component.buffetBookingForm.controls['plateCount'];
        plateCount.setValue(6);
        plateCount.markAsDirty();
        fixture.detectChanges();
        plateCountSpan = fixture.debugElement.query(By.css('#plateCountError'));
        errors = plateCount.errors;
      });

      it('TSC 23/60 - Plate count should be valid', () => {
        expect(plateCount.valid).toBeTruthy();

      });

      it('TSC 24/60 - Plate count should not contain error', () => {
        expect(errors).toBeFalsy();

      });

      it('TSC 25/60 - Plate count should not display the error message', () => {
        expect(plateCountSpan).toBeFalsy();
      });
    })

    //Incorrect value for Plate count
    describe('Plate count field when incorrect value is given', () => {
      let errors;
      let plateCount: AbstractControl;
      let plateCountSpan;

      beforeEach(() => {
        plateCount = component.buffetBookingForm.controls['plateCount'];
        plateCount.setValue(4);
        plateCount.markAsDirty();
        fixture.detectChanges();
        plateCountSpan = fixture.debugElement.query(By.css('#plateCountError'));
        errors = plateCount.errors;
      });

      it('TSC 26/60 - Plate count with invalid value', () => {
        expect(plateCount.valid).toBeFalsy();
      })

      it('TSC 27/60 - Plate Count fails wrt min property', () => {
        expect(errors['min']).toBeTruthy();
      })

      it('TSC 28/60 - Plate Count should display error message', () => {
        expect(plateCountSpan).toBeTruthy();
      })
    });

    //////////////////////// 4th Field /////////////////////////////

    //Booked on field without value
    describe('No value provided for Booked on field', () => {
      let errors;
      let bookedOn: AbstractControl;
      let bookedOnSpan;

      beforeEach(() => {
        bookedOn = component.buffetBookingForm.controls['bookedOn'];
        bookedOn.setValue('');
        fixture.detectChanges();
        errors = bookedOn.errors;
        bookedOnSpan = fixture.debugElement.query(By.css('#bookedOnError'));
      });

      it('TSC 29/60 - Booked on should be invalid', () => {
        expect(bookedOn.valid).toBeFalsy();
      });

      it('TSC 30/60 - Booked on should contain required error', () => {
        expect(errors['required']).toBeTruthy();

      });

      it('TSC 31/60 - Booked on should not display the error message initialy', () => {
        expect(bookedOnSpan).toBeFalsy();
      });
    })

    describe('Valid value for booked on field', () => {
      let errors;
      let bookedOn: AbstractControl;
      let bookedOnSpan;

      beforeEach(() => {
        bookedOn = component.buffetBookingForm.controls['bookedOn'];
        bookedOn.setValue(new Date(2018, 2, 3));
        fixture.detectChanges();
        errors = bookedOn.errors;
        bookedOnSpan = fixture.debugElement.query(By.css('#bookedOnError'));
      });

      it('TSC 32/60 - Booked on should be valid', () => {
        expect(bookedOn.valid).toBeTruthy();
      });

      it('TSC 33/60 - Booked on should not contain error', () => {
        expect(errors).toBeFalsy();
      });

      it('TSC 34/60 - Booked on should not display the error message', () => {
        expect(bookedOnSpan).toBeFalsy();
      })
    })
  });

  ///////////////////FormSubmission//////////////////
  describe('Submiting invalid data', () => {

    let submitBtn;

    beforeEach(() => {
      component.buffetBookingForm.controls['buffetName'].setValue('ChineeseSpecial');
      component.buffetBookingForm.controls['emailId'].setValue('renny@infy');
      component.buffetBookingForm.controls['plateCount'].setValue('2.5');
      component.buffetBookingForm.controls['bookedOn'].setValue(new Date("June 6, 2018 00:00:00"));
      fixture.detectChanges();
      submitBtn = fixture.debugElement.query(By.css('button')).nativeElement;
    })

    it('TSC 35/60 - Form level validation should be invalid', () => {
      expect(component.buffetBookingForm.valid).toBe(false);
    });

    it('TSC 36/60 - Submit button should have disabled property', () => {
      expect(submitBtn.disabled).toBe(true);
    });

  })

  ///////////////////Form element binding//////////////////
  describe('Checking HTML form elements binding', () => {

    let buffetBookingFormTag: DebugElement;
    let buffetNameTag: DebugElement;
    let emailIdTag: DebugElement;
    let plateCountTag: DebugElement;
    let bookedOnTag: DebugElement;

    beforeEach(() => {
      buffetBookingFormTag = fixture.debugElement.query(By.css('form'));
      buffetNameTag = fixture.debugElement.query(By.css('#buffetName'));
      emailIdTag = fixture.debugElement.query(By.css('#emailId'));
      plateCountTag = fixture.debugElement.query(By.css('#plateCount'));
      bookedOnTag = fixture.debugElement.query(By.css('#bookedOn'))
    });

    it('TSC 37/60 - check binding of formgroup to form tag', () => {
      expect(buffetBookingFormTag.attributes['ng-reflect-form']).toBeTruthy();
    });

    it('TSC 38/60 - check buffetName tag is binded correctly', () => {
      expect(buffetNameTag.attributes['formControlName']).toBe('buffetName');
    });

    it('TSC 39/60 - check emailId tag is binded correctly', () => {
      expect(emailIdTag.attributes['formControlName']).toBe('emailId');
    });

    it('TSC 40/60 - check plateCount tag is binded correctly', () => {
      expect(plateCountTag.attributes['formControlName']).toBe('plateCount');
    });

    it('TSC 41/60 - check bookedOn tag is binded correctly', () => {
      expect(bookedOnTag.attributes['formControlName']).toBe('bookedOn');
    });
  })

  ///////////////////Calling the method on form submit//////////////////
  describe('Submitting valid data', () => {

    beforeEach(() => {
      component.buffetBookingForm.controls['buffetName'].setValue('ChineeseSpecial');
      component.buffetBookingForm.controls['emailId'].setValue('renny@infy');
      component.buffetBookingForm.controls['plateCount'].setValue('12');
      component.buffetBookingForm.controls['bookedOn'].setValue(new Date("June 7, 2018 00:00:00"));
      fixture.detectChanges();
    });

    it('TSC 42/60 Check if the bookBuffet() method calls service', () => {
      const spy = spyOn(buffetBookingService, "bookBuffet").and.returnValue(of({ message: 'Success' }));
      component.bookBuffet();
      expect(spy).toHaveBeenCalled();
    })

    it('TSC 43/60 Check if the bookBuffet() method nullifies the messages', () => {
      spyOn(buffetBookingService, "bookBuffet").and.returnValue(of({ message: 'Success message is populated' }));
      // spyOn(null, "subscribe").and.stub();
      component.bookBuffet();
      expect(component.errorMessage).toBe(null);
    })
    it('TSC 44/60 Check if the bookBuffet() method nullifies the messages', () => {
      spyOn(buffetBookingService, "bookBuffet").and.returnValue(throwError({ error: { message: 'Failure message is populated' } }));
      // spyOn(null, "subscribe").and.stub();
      component.bookBuffet();
      expect(component.successMessage).toBe(null);
    })

    it('TSC 45/60 On calling service, success message must be populated', fakeAsync(() => {
      spyOn(buffetBookingService, "bookBuffet").and.returnValue(of({ message: 'Success message is populated' }));
      component.bookBuffet();
      tick();
      expect(component.successMessage).toBe("Success message is populated")
    }));

    it('TSC 46/60 On calling service, error message must be populated', fakeAsync(() => {
      spyOn(buffetBookingService, "bookBuffet").and.returnValue(throwError({ error: { message: 'Failure message is populated' } }));
      component.bookBuffet();
      tick();
      expect(component.errorMessage).toBe("Failure message is populated")
    }));
  })

  ///////////////////Checking for bootstrap classes//////////////////
  describe('Check if bootstrap classes are used', () => {
    let buffetBookingFormTag: DebugElement;
    let buffetNameTag: DebugElement;
    let emailIdTag: DebugElement;
    let plateCountTag: DebugElement;
    let bookedOnTag: DebugElement;
    let buttonTag: DebugElement;

    let buffetNameErrorTag: DebugElement;
    let emailIdErrorTag;
    let plateCountErrorTag: DebugElement;
    let bookedOnErrorTag: DebugElement;

    beforeEach(() => {
      component.buffetBookingForm.controls['buffetName'].setValue(undefined);
      component.buffetBookingForm.controls['emailId'].setValue('andy@');
      component.buffetBookingForm.controls['plateCount'].setValue(3);
      component.buffetBookingForm.controls['bookedOn'].setValue(null);

      component.buffetBookingForm.controls['buffetName'].markAsDirty();
      component.buffetBookingForm.controls['emailId'].markAsDirty();
      component.buffetBookingForm.controls['plateCount'].markAsDirty();
      component.buffetBookingForm.controls['bookedOn'].markAsDirty();

      fixture.detectChanges();

      buffetBookingFormTag = fixture.debugElement.query(By.css('form'));
      buffetNameTag = fixture.debugElement.query(By.css('#buffetName'));
      emailIdTag = fixture.debugElement.query(By.css('#emailId'));
      plateCountTag = fixture.debugElement.query(By.css('#plateCount'));
      bookedOnTag = fixture.debugElement.query(By.css('#bookedOn'))

      buffetNameErrorTag = fixture.debugElement.query(By.css('#buffetNameError'));
      emailIdErrorTag = fixture.debugElement.query(By.css('#emailIdError'));
      plateCountErrorTag = fixture.debugElement.query(By.css('#plateCountError'));
      bookedOnErrorTag = fixture.debugElement.query(By.css('#bookedOnError'));

      buttonTag = fixture.debugElement.query(By.css('button'));
    });

    it("TSC 47/60 form tag has class form", () => {
      expect(buffetBookingFormTag.attributes['class']).toBe('form');
    })

    it("TSC 48/60 Buffet name tag has class form-group", () => {
      expect(buffetNameTag.parent.attributes['class']).toBe('form-group');
    })

    it('TSC 49/60 Buffet name tag has class form-control', () => {
      expect(buffetNameTag.attributes['class']).toBe('form-control');
    })

    it("TSC 50/60 Email id tag has class form-group", () => {
      expect(emailIdTag.parent.attributes['class']).toBe('form-group');
    })

    it('TSC 51/60 Email id tag has class form-control', () => {
      expect(emailIdTag.attributes['class']).toBe('form-control');
    })

    it("TSC 52/60 Plate count tag has class form-group", () => {
      expect(plateCountTag.parent.attributes['class']).toBe('form-group');
    })

    it('TSC 53/60 Plate count tag has class form-control', () => {
      expect(plateCountTag.attributes['class']).toBe('form-control');
    })

    it("TSC 54/60 Booked ont tag has class form-group", () => {
      expect(bookedOnTag.parent.attributes['class']).toBe('form-group');
    })

    it('TSC 55/60 Booked on tag has class form-control', () => {
      expect(bookedOnTag.attributes['class']).toBe('form-control');
    })

    it("TSC 56/60 button should have class btn btn-primary", () => {
      expect(buttonTag.attributes['class']).toBe('btn btn-primary');
    })

    it('TSC 57/60 Buffet name tag should have class error-message', () => {
      expect(buffetNameErrorTag.attributes['class']).toBe('error-message')
    })

    it('TSC 58/60 Email id tag should have class error-message', () => {
      expect(emailIdErrorTag.attributes['class']).toBe('error-message')
    })

    it('TSC 59/60 Plate count tag should have class error-message', () => {
      expect(plateCountErrorTag.attributes['class']).toBe('error-message')
    })

    it('TSC 60/60 Booked on tag should have class error-message', () => {
      expect(bookedOnErrorTag.attributes['class']).toBe('error-message')
    })
  })
});
