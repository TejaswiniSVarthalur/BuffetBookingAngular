// import { MessagePipe } from '../buffet-booking/message.pipe';

// describe('Test MessagePipe', () => {
//   let pipe;
//   beforeEach(() => {
//       pipe = new MessagePipe();
//   });

//   it('TCP 1/2 - create an instance', () => {
//     expect(pipe).toBeTruthy();
//   });

//   it('TCP 2/2 - Transform data',()=>{
//     let testInput = 2001;
//     expect(pipe.transform(testInput)).toBe("Buffet booked with booking id "+testInput)
//   })
// })
