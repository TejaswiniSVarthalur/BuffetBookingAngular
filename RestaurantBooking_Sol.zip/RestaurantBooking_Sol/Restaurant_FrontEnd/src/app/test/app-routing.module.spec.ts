import { routes } from '../app-routing.module';

describe("AppRoutingModule",()=>{

    it('TRM 1/2 Check whether the routing is given properly', ()=>{
        let pathGiven = routes[0].path;
        let componentGiven = routes[0].component.name;
        let flag = /^[\/]?bookBuffet$/.test(pathGiven) && componentGiven == "BuffetBookingComponent";
        expect(flag).toBeTruthy();
    });

    it('TRM 2/2 Check whether the Catch-all is provided', ()=>{
        let pathGiven = routes[1].path;
        let redirectTo = routes[1].redirectTo;
        let pathMatch = routes[1].pathMatch; 
        let flag = /^\*\*$/.test(pathGiven) && redirectTo == '' && pathMatch =='full';
        expect(flag).toBeTruthy();
    })
})