import { TestBed, inject } from '@angular/core/testing';

import { GetBookingService } from './get-booking.service';

describe('GetBookingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetBookingService]
    });
  });

  it('should be created', inject([GetBookingService], (service: GetBookingService) => {
    expect(service).toBeTruthy();
  }));
});
