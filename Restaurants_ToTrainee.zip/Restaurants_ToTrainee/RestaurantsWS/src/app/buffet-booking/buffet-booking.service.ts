import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BuffetBooking } from './buffet-booking';

@Injectable()
export class BuffetBookingService {

  constructor() { }

  bookBuffet(data): Observable<BuffetBooking>{
    return;
  }

}
