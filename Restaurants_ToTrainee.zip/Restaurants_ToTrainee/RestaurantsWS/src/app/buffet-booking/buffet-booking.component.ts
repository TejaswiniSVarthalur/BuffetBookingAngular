import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

import { BuffetBookingService } from './buffet-booking.service';

@Component({
  selector: 'app-buffet-booking',
  templateUrl: './buffet-booking.component.html',
  styleUrls: ['./buffet-booking.component.css']
})
export class BuffetBookingComponent implements OnInit {

  constructor() { }



  ngOnInit() {
  }

  bookBuffet(){
    return;
  }

}
