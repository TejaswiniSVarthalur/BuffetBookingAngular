import { PlateCountPipe } from './plate-count.pipe';

describe('PlateCountPipe', () => {
  it('create an instance', () => {
    const pipe = new PlateCountPipe();
    expect(pipe).toBeTruthy();
  });
});
